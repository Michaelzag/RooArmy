# RooCommander Configuration

## Project Profile
- **Main Language**: [language]
- **Frameworks**: [framework] v[version], [framework] v[version]
- **Project Type**: [type]
- **Database**: [database] v[version]

## Team Structure
- **Size**: [size]
- **Experience Level**: [level]
- **Key Roles**: [role], [role], [role]

## Selected Modes
- [mode] ([purpose])
- [mode] ([purpose])
- [mode] ([purpose])

## Reference Documentation
- [path/to/reference-doc1.md]
- [path/to/reference-doc2.md]
- [path/to/reference-doc3.md]

## Configuration History
- **Initial Setup**: [date]
- **Last Modified**: [date] ([change description])

## Notes
[Any additional notes about the configuration]